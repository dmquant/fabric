# Task: Investigate the root cause of the $18.95 billion income tax expense anomaly in Q3 2025, which caused a reported 83% plunge in net income, by summarizing management's explanation from the earnings call and identifying the specific legal settlement or tax law change responsible.

---

### Meta Records $18.95 Billion Tax Anomaly in Q3 2025 Due to New Tax Law

**MENLO PARK, Calif.** - Meta Platforms, Inc. (META) reported a staggering $18.954 billion income tax expense for the third quarter of 2025, causing an 83% plunge in net income to $2.709 billion, despite robust revenue growth. This anomaly was primarily caused by a one-time, non-cash charge related to the enactment of new U.S. tax legislation.

The specific piece of legislation responsible for this significant financial impact is the "One Big Beautiful Bill Act" (OBBBA), which was signed into law on July 4, 2025. The implementation of this act, along with the application of the U.S. Corporate Alternative Minimum Tax (AMT), prompted Meta to recognize a valuation allowance against its U.S. federal deferred tax assets. This resulted in a one-time, non-cash income tax charge of $15.93 billion.

According to a transcript of the earnings call, management clarified the impact, stating that the effective tax rate for the quarter was 87%. Excluding the one-time charge, the effective tax rate would have been 14%, a figure more aligned with previous quarters. Adjusted for this charge, net income would have been $18.64 billion, and diluted earnings per share (EPS) would have been $7.25, a stark contrast to the reported $1.05.

The "One Big Beautiful Bill Act" represents a significant tax reform for technology companies. One of its key provisions is the permanent restoration of immediate deductions for domestic research and experimentation (R&E) expenses, reversing a 2022 rule that required amortization of these costs.

Despite the substantial one-time charge, Meta's management indicated that the new tax law is expected to significantly reduce the company's U.S. federal cash tax payments for the remainder of 2025 and in future years. Following the announcement, the company's stock fell more than 8% in after-hours trading, reflecting investor concerns over the reported net income and increased spending forecasts. The company also raised its annual capital expenditure outlook to between $70 billion and $72 billion, citing aggressive expansion of its AI infrastructure. For the fourth quarter of 2025, Meta projects a tax rate between 12% and 15%, assuming no further changes to the tax landscape.