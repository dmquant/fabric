# Task: Analyze the significant increase in projected 2025 and 2026 capital expenditures, with a focus on the allocation of funds between AI infrastructure, data centers, and Reality Labs, and assess the market's negative reaction to this 'runaway' spending.

---

### Meta's Aggressive AI-Fueled Spending Sparks Investor Alarm

**Menlo Park, CA –** Meta Platforms has announced a dramatic escalation in its capital expenditure plans for 2025 and 2026, signaling an aggressive, all-in strategy to establish leadership in artificial intelligence. The company now projects capital expenditures for 2025 to be in the range of $70 billion to $72 billion, a significant jump from the $37.3 billion spent in 2024. Projections for 2026 indicate an even more substantial increase, with executives warning that spending will be "notably larger" than in 2025, potentially exceeding $100 billion.

This surge in spending is predominantly aimed at building a formidable infrastructure for artificial intelligence, encompassing a massive expansion of data centers, the procurement of high-end servers and AI chips, and a hiring blitz for top-tier technical talent. The unprecedented investment has rattled investors, triggering a significant sell-off in Meta's stock and raising concerns about the long-term impact on profitability and cash flow.

#### Allocation of Funds: An AI Arms Race

The vast majority of the increased capital is earmarked for building out the necessary infrastructure to support Meta's ambitious AI roadmap, including the pursuit of "superintelligence," a hypothetical point where machine cognition surpasses human intellect.

**Key Investment Areas:**

*   **AI Infrastructure and Data Centers:** The core of the spending is on physical infrastructure. Meta is investing tens of billions to construct a new generation of data centers specifically designed for the immense computational demands of AI. The company's goal is to bring approximately 1 gigawatt of new computing capacity online in 2025 alone and to possess more than 1.3 million GPUs by the end of that year. To fund this expansion, Meta is not only using its own capital but is also reportedly selling billions in corporate bonds and entering into joint ventures, such as one with Blue Owl Capital for the Hyperion data center campus.
*   **Talent Recruitment:** A significant portion of the increased expenses is allocated to employee compensation to attract and retain elite AI researchers and engineers. Meta has been on a hiring spree, reportedly offering lucrative packages to secure top talent from competitors like OpenAI and Google to staff its new "Meta Superintelligence Labs" (MSL). This new unit has consolidated the company's AI teams to accelerate progress.
*   **Reality Labs:** While the primary driver of the capex increase is AI infrastructure that benefits the entire company, the Reality Labs division, which focuses on the metaverse and VR/AR hardware like the Quest headsets, continues to be a major area of investment. Despite consistently posting significant operating losses—losing $4.4 billion in the third quarter of 2025—the division remains a long-term strategic priority for CEO Mark Zuckerberg, who sees an eventual convergence of AI and immersive technologies.

#### Market's Negative Reaction: Concerns Over "Runaway" Spending

The announcement of the accelerated spending plans was met with immediate and forceful negativity from the market. Following the guidance update during its Q3 2025 earnings call, Meta's shares plunged by over 11%, marking the stock's largest single-day drop since October 2022. This wiped approximately $190 billion off the company's market capitalization, reflecting deep investor anxiety.

**Primary Investor Concerns:**

*   **Uncertain Return on Investment (ROI):** The central fear for investors is the uncertainty and extended timeline for generating significant returns from these massive AI investments. Analysts have questioned how and when Meta will monetize its pursuit of superintelligence and other advanced AI products. Mark Zuckerberg has admitted that spending will have to grow "meaningfully" before the company makes "much revenue" from new AI products.
*   **Pressure on Profit Margins and Cash Flow:** Wall Street is concerned that the surge in both capital expenditures and operating expenses will outpace revenue growth, thereby compressing profit margins. The company itself has stated that total expenses in 2026 will grow at a "significantly faster percentage rate" than in 2025, driven primarily by infrastructure costs.
*   **Echoes of the Metaverse Bet:** The aggressive spending reminds investors of Meta's earlier, multi-billion-dollar pivot to the metaverse, a venture that has so far accumulated over $70 billion in losses since late 2020 without producing meaningful financial returns. This history has made the market cautious about another ambitious, high-cost project with a long and uncertain path to profitability.

Despite the market's apprehension, Meta's leadership remains resolute. CEO Mark Zuckerberg defended the strategy, arguing for the necessity of "aggressively front-loading" capacity to be prepared for future AI breakthroughs. The company points to the strong performance of its core advertising business, which is already benefiting from AI-driven tools and optimizations, as justification for the massive outlay. However, for the near future, the market's focus will remain on the tension between Meta's long-term AI vision and the immediate financial impact of its "runaway" spending.