# Task: Evaluate the performance and monetization progress of the Reality Labs division, considering its recurring quarterly losses ($4.43 billion in Q3 2025) against its revenue growth and the strategic shift toward AI-driven hardware like smart glasses.

---

### Reality Labs' Mounting Losses Weighed Against Revenue Growth and AI Pivot

Meta's Reality Labs division continues to be a significant financial drain, posting a substantial $4.4 billion operating loss in the third quarter of 2025. This brings the division's cumulative operating losses to over $70 billion since late 2020, underscoring the high cost of the company's long-term bet on virtual and augmented reality. Despite the staggering losses, the division saw a significant 74% year-over-year revenue increase in the same quarter, reaching $470 million. This growth, coupled with a strategic shift toward AI-integrated hardware like smart glasses, presents a complex picture of the division's performance and future prospects.

#### Financial Performance: A Deep Dive

**Persistent Losses:** The Reality Labs division remains deeply unprofitable, with Q3 2025 losses of over $4.4 billion stemming from expenses of $4.9 billion against revenues of just $470 million. While this was slightly better than the $4.5 billion loss in the prior quarter, it represented an increase in losses year-over-year. These ongoing losses highlight the immense capital investment required for research and development in nascent technologies like AR glasses, which constituted over half of the division's spending as of 2022.

**Context of Meta's Overall Health:** While Reality Labs consistently loses billions, Meta's core advertising business remains incredibly strong. In Q3 2025, the company as a whole posted revenues of $51.24 billion, a 26% year-over-year increase, with an operating income of $20.53 billion. This robust performance from the "Family of Apps" segment currently subsidizes the ambitious and costly vision of Reality Labs.

**Revenue Bright Spots:** The 74% year-over-year revenue growth for Reality Labs in Q3 2025 was a notable positive. This was attributed to two main factors: strong revenue from AI-powered smart glasses and retailers stocking up on Quest headsets in preparation for the holiday season. However, Meta's CFO Susan Li has cautioned that this early stocking by retailers means that Q4 2025 revenue for the division is expected to be lower than the previous year.

#### Strategic Pivot to AI and Smart Glasses

Meta's strategy for Reality Labs appears to be undergoing a significant evolution, with a clearer emphasis on AI-driven wearable devices, particularly smart glasses.

**Shift in Focus:** The reassignment of Meta's former metaverse chief, Vishal Shah, to lead AI product integration within Reality Labs signals a strategic pivot. The focus is shifting from building immersive virtual worlds to integrating AI into hardware that people can use in their daily lives. CEO Mark Zuckerberg has stated that AI glasses could be the "ideal form factor" for AI-driven personal computing.

**Success of Ray-Ban Meta Smart Glasses:** The collaboration with EssilorLuxottica on Ray-Ban and Oakley branded smart glasses is showing significant promise.
*   **Strong Sales Growth:** Sales of Ray-Ban Meta smart glasses tripled in the first half of 2025 compared to the same period in the prior year. Since their debut in late 2023, over 2 million units have been sold.
*   **Market Leadership:** Meta has established a dominant position in the burgeoning AI smart glasses market, capturing over 73% of the market share in the first half of 2025.
*   **Increasing Demand:** Demand for the smart glasses is reportedly outpacing Meta's ability to manufacture them, with the company's partner, EssilorLuxottica, planning to increase annual production capacity to 10 million units by 2026.

**Monetization Strategy:** Zuckerberg has indicated that the path to profitability for these devices involves initial hardware sales followed by the development of "services" built on top of that hardware. This strategy mirrors the successful models of other major tech ecosystems.

#### The Road Ahead

Despite the early success of smart glasses, the financial outlook for Reality Labs remains challenging. CFO Susan Li has stated that while they expect "significant YoY growth in AI glasses revenue" in Q4, these gains will be "more than offset by the headwinds of Quest headsets," as there is no new headset launch planned for the 2025 holiday season.

Meta's leadership continues to frame the massive expenditures in Reality Labs and broader AI infrastructure as essential "front-loading" of investments that will be "very likely to be a profitable thing" in the long term. The company is significantly increasing its capital expenditure forecasts for 2025 and 2026 to build out the necessary computing infrastructure to support its AI ambitions.

In conclusion, while the headline losses for Reality Labs are substantial and ongoing, the strong revenue growth and the promising traction of the new AI-powered smart glasses suggest a potential, albeit long and expensive, path toward monetization. The strategic pivot from a pure metaverse focus to more immediate, real-world AI applications through wearables appears to be a pragmatic and potentially more viable approach. The success of this division remains a long-term, high-risk venture that will continue to weigh on Meta's overall profitability for the foreseeable future.