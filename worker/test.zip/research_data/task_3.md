# Task: Assess the strength of Meta's core advertising business by analyzing the drivers of the 26% year-over-year revenue growth in Q3 2025, including the 14% increase in ad impressions and 10% rise in average price per ad.

---

## Meta's Advertising Powerhouse Fuels Robust Growth

Meta's core advertising business demonstrated significant strength in the third quarter of 2025, driving a 26% year-over-year revenue increase to $51.24 billion. This impressive growth was underpinned by a healthy and balanced combination of a 14% rise in ad impressions and a 10% increase in the average price per ad, signaling robust health in both user engagement and advertiser demand.

The quarterly revenue figure of $51.24 billion marks a substantial increase from the $40.59 billion reported in the same period of the previous year. This performance contributed to a strong operating income of $20.54 billion and an operating margin of 40%.

### Key Drivers of Growth:

**Increased Ad Impressions (Volume):** The 14% year-over-year growth in ad impressions across Meta's Family of Apps was a primary volume driver for the revenue surge. This increase can be attributed to several key factors:
*   **Growing User Base:** Meta's Family of Apps (including Facebook, Instagram, Messenger, WhatsApp, and Threads) saw its daily active people (DAP) grow by 8% year-over-year, reaching an average of 3.54 billion for September 2025. This expanding user base provides a larger audience for advertisers.
*   **Higher Engagement:** User engagement has been bolstered by AI-driven recommendation systems. These enhancements have led to a 5% increase in time spent on Facebook and a 10% increase on Threads. Video content, in particular, has seen a surge, with time spent on Instagram videos up more than 30% since the previous year.
*   **Reels Monetization:** The increasing popularity and monetization of Reels have created significant new ad inventory. Reels now command an annual revenue run rate of over $50 billion, indicating its successful integration into the advertising ecosystem.

**Higher Average Price Per Ad (Value):** The 10% year-over-year increase in the average price per ad underscores strong advertiser demand and a willingness to pay more for placements. This pricing power is driven by:
*   **AI-Powered Ad Performance:** Meta's significant investments in AI are yielding substantial returns for advertisers. The company's AI-driven ad ranking and recommendation systems are improving ad relevance and performance.
*   **Advantage+ Suite Adoption:** The company's automated advertising tools, known as the Advantage+ suite, have seen strong uptake. These AI-powered solutions automate targeting, creative testing, and budget allocation, leading to higher return on ad spend (ROAS) and lower costs per acquisition for advertisers. The annual revenue run rate for Meta's AI-powered ad solutions has now surpassed $60 billion.
*   **Strong Advertiser Demand:** The growth in ad pricing reflects steady and robust demand from advertisers across global markets. This is part of a broader trend of strong ad spending in the digital market.
*   **Growth in High-Value Formats:** The rapid expansion of click-to-WhatsApp ads, which saw a 60% revenue increase, highlights the growth of high-value conversational commerce formats that command higher prices.

### Broader Financial Context

The strength of the advertising business is reflected in the company's overall financial health. The Family of Apps segment, which houses the core ad business, generated $50.77 billion of the total Q3 revenue. While the company's net income was significantly impacted by a one-time, non-cash tax charge of $15.93 billion, the adjusted net income stood at a strong $18.64 billion, underscoring the core business's profitability.

Meta's ability to grow both the volume of ads served and the price advertisers are willing to pay for them demonstrates a powerful and efficient advertising engine. The continued investment in AI to enhance user engagement and deliver superior returns for advertisers positions Meta's core business for sustained performance.