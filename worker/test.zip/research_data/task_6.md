# Task: Deconstruct the drivers of the 32% year-over-year increase in total expenses for Q3 2025, separating legal-related costs, AI talent acquisition, and infrastructure spending to understand their impact on the operating margin compression.

---

### **Meta's Expenses Surge 32% in Q3 2025, Squeezing Operating Margin Amidst Aggressive AI Push and Rising Legal Costs**

**Menlo Park, CA –** Meta Platforms, Inc. (META) reported a robust 26% year-over-year revenue increase to $51.24 billion for the third quarter of 2025. However, this strong top-line growth was overshadowed by a significant 32% surge in total expenses, which climbed to $30.71 billion from $23.24 billion in the same period last year. This accelerated spending led to a compression in the company's operating margin, which fell to 40% from 43% in Q3 2024.

The primary drivers behind this substantial increase in expenditures are heightened legal-related costs, a continued aggressive push for top-tier AI talent, and massive investments in infrastructure to support the company's ambitions in artificial intelligence.

#### **Deconstruction of Expense Drivers:**

The 32% year-over-year increase in total costs, amounting to an additional $7.47 billion, can be broken down across Meta's key expense categories:

*   **General and Administrative (G&A):** This category saw the most dramatic percentage increase, soaring 88.3% from $1.87 billion in Q3 2024 to $3.51 billion in Q3 2025. A significant portion of this is attributed to unspecified "legal-related expenses" and "legal charges". While the exact details of these charges were not fully disclosed, they were a primary contributor to the sharp acceleration in expense growth. The company has also been navigating increasing regulatory headwinds in the European Union and the United States, which could lead to further significant impacts on its financial results.

*   **Research and Development (R&D):** As the largest component of Meta's operating expenses, R&D costs grew by 35.5%, from $11.18 billion to $15.14 billion. This increase is a direct result of Meta's aggressive "AI hiring spree" and substantial investments in talent to build out its "Meta Superintelligence Labs". The company has been reportedly offering multi-million dollar compensation packages to lure top AI researchers and engineers from competitors. CFO Susan Li confirmed that "increased AI talent acquisition" was a key driver of expenses, with employee compensation costs expected to be the second-largest contributor to expense growth as the company recognizes a full year of compensation for these strategic hires. Headcount was up 8% year-over-year to over 78,400 employees.

*   **Cost of Revenue & Infrastructure Spending:** Cost of revenue increased by 24.8% to $9.21 billion. This is tightly linked to Meta's massive infrastructure investments. Capital expenditures for the quarter reached $19.37 billion, more than double the figure from the previous year. These investments are being poured into AI data centers and computing infrastructure to expand capacity for AI software. The company raised its full-year 2025 capital expenditure guidance to a range of $70-72 billion and signaled that spending will be "notably larger" in 2026. These infrastructure costs manifest on the income statement as higher depreciation and costs tied to a larger data-center footprint and third-party cloud usage.

#### **Impact on Operating Margin:**

The 32% rise in total expenses outpaced the 26% revenue growth, leading to a 3-percentage-point compression in operating margin from 43% in Q3 2024 to 40% in Q3 2025. The significant increases in legal costs (G&A), salaries for specialized technical talent (R&D), and the operational costs of a rapidly expanding AI infrastructure (Cost of Revenue and Depreciation) were the direct causes of this margin pressure.

Investors have shown concern over the escalating costs, with the company's stock declining after the earnings announcement, despite strong revenue performance. Management has defended the aggressive spending as a necessary front-loading of investment to build capacity and secure a leading position in what they see as a generational paradigm shift toward AI. CFO Susan Li stated that the company will need to "invest aggressively" in 2026 to meet its computational needs, with expenses expected to grow at a "significantly faster" rate than in 2025, driven primarily by infrastructure costs.