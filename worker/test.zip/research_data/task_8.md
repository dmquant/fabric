# Task: Review and summarize recent changes in analyst ratings and price targets for META following the Q3 2025 earnings report, noting the downgrade from at least one firm and the overall consensus rating.

---

### Analyst Ratings Shift for Meta Following Turbulent Q3 2025 Earnings Report

**Following a tumultuous third-quarter earnings report that saw a dramatic drop in net income despite record revenue, analysts have adjusted their outlooks on Meta Platforms, Inc. (META), resulting in at least one downgrade and several downward revisions to price targets. The stock experienced a significant sell-off, dropping over 11% to below $700, as investors reacted to a massive one-time tax expense and escalating capital expenditure forecasts related to the company's aggressive push into artificial intelligence.**

Meta's third-quarter results presented a mixed financial picture. The company reported a robust 26% year-over-year increase in revenue to $51.24 billion, surpassing Wall Street estimates. However, this strong top-line growth was overshadowed by an 83% plunge in net income to $2.71 billion, or $1.05 per diluted share. This sharp decline was primarily due to a one-time, non-cash income tax charge of $15.93 billion associated with the "One Big Beautiful Bill Act." Excluding this charge, net income would have been approximately $18.64 billion.

The significant tax charge, coupled with increased spending guidance, prompted varied reactions from Wall Street. Oppenheimer downgraded Meta from “Outperform” to “Perform,” drawing parallels between the current heavy investment in AI and the company's costly, and so far unprofitable, venture into the metaverse.

Several other firms, while maintaining their buy-equivalent ratings, lowered their price targets. Bank of America reduced its price target from $900 to $810, and Piper Sandler adjusted its target from $900 to $825. Mizuho also lowered its price target from $925 to $815, citing concerns about the monetization pathway for Meta's substantial AI investments. Similarly, TD Cowen decreased its price target from $875 to $810.

A key concern highlighted by analysts is Meta's escalating spending. The company narrowed its 2025 capital expenditure guidance to a range of $70 billion to $72 billion and indicated that spending in 2026 would be "notably larger." This aggressive investment in AI infrastructure, including data centers and talent, has raised questions about near-term profitability and the return on investment.

Despite the downgrades and price target reductions from some firms, the overall analyst consensus for Meta remains largely positive. The consensus rating is a "Strong Buy" or "Moderate Buy," according to various financial news outlets. The consensus price target among analysts ranges from approximately $824 to $872, suggesting potential upside from the stock's post-earnings price. Some analysts believe the sell-off was an overreaction to the one-time tax expense and that the company's core business fundamentals, including strong user growth and ad revenue, remain intact.