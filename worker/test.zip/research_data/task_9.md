# Task: Analyze Meta's capital return strategy by quantifying the impact of the $3.16 billion in share repurchases and $1.33 billion in dividend payments in Q3 2025 on shareholder value, in the context of rising capital expenditures.

---

### Meta's Balancing Act: Returning Billions to Shareholders Amidst Surging AI Investments

**Menlo Park, CA –** In the third quarter of 2025, Meta Platforms (META) executed a significant capital return to its shareholders, distributing a combined $4.49 billion through share repurchases and its recently instituted dividend. This move underscores the technology giant's commitment to delivering shareholder value, even as it aggressively ramps up capital expenditures to fuel its ambitions in artificial intelligence.

In Q3 2025, Meta repurchased $3.16 billion of its Class A common stock and paid out $1.33 billion in dividends. This capital return strategy is set against a backdrop of accelerating investments, with capital expenditures, including finance lease payments, reaching $19.37 billion in the same quarter. The company's financial disclosures reveal a delicate balancing act between rewarding current investors and making substantial, long-term bets on future growth.

#### Share Repurchases: A Sign of Confidence and a Boost to EPS

The $3.16 billion spent on share buybacks in the third quarter is a continuation of Meta's long-standing practice of returning capital to shareholders through this method. By reducing the number of outstanding shares, these repurchases can have a positive impact on earnings per share (EPS). In Q3 2025, Meta reported diluted weighted average shares outstanding of 2.572 billion, a slight decrease from 2.600 billion in the same quarter of the previous year.

Stock buybacks are often interpreted by the market as a signal from management that they believe the company's shares are undervalued. This can help to bolster investor confidence and provide support for the stock price. For existing long-term shareholders, repurchases increase their proportional ownership of the company.

However, the decision to allocate billions to buybacks is not without scrutiny, particularly as Meta's capital expenditures are projected to be between $70 billion and $72 billion for the full year of 2025, a significant increase from previous forecasts. Some investors may question whether this capital could be better utilized for even more aggressive investment in AI and the metaverse to accelerate future growth.

#### Dividends: A Commitment to Sustainable Returns

In addition to buybacks, Meta distributed $1.33 billion in dividend payments in the third quarter. The initiation of a dividend in early 2024 marked a new phase in the company's capital allocation strategy, signaling a commitment to providing a direct and regular cash return to investors. This can broaden the appeal of Meta's stock to a more diverse investor base, including those focused on income.

The sustainability of the dividend appears robust. In Q3 2025, the $1.33 billion in dividend payments represented a manageable portion of the company's net income and an even smaller fraction of its substantial free cash flow of $10.62 billion. This suggests that Meta has ample capacity to maintain and potentially grow its dividend in the future, even with its elevated investment levels. The company announced a 5% increase to its quarterly dividend in the first quarter of 2025.

#### The Context of Soaring Capital Expenditures

Meta's capital return strategy is particularly noteworthy given the dramatic increase in its capital expenditures. The company has explicitly stated that it is investing heavily in servers, data centers, and network infrastructure to support its AI initiatives. CFO Susan Li has indicated that capital expenditure growth in 2026 is expected to be "notably larger" than in 2025, with total expenses also projected to grow at a "significantly faster" rate.

This aggressive spending is aimed at building the necessary infrastructure for what CEO Mark Zuckerberg calls "personal superintelligence". While these investments are crucial for Meta to remain competitive in the burgeoning AI landscape, they also introduce a level of risk and uncertainty regarding the timing and magnitude of future returns.

Despite these massive outlays, Meta's strong operational performance provides a solid foundation. In Q3 2025, the company generated $30.0 billion in cash flow from operating activities, which was more than sufficient to cover both its capital expenditures and its capital returns to shareholders.

#### The Impact on Shareholder Value

Meta's dual approach of returning capital to shareholders while simultaneously making massive investments in its future presents a complex picture for investors.

The share repurchases and dividends provide tangible returns and signal management's confidence in the company's financial strength. The reduction in share count can enhance per-share metrics, while the dividend offers a regular income stream.

However, the escalating capital expenditures, projected to potentially exceed $100 billion in 2026, have raised concerns among some investors about the impact on near-term profitability and margins. The long-term success of this strategy will ultimately depend on Meta's ability to successfully monetize its AI investments and demonstrate a clear return on this substantial capital deployment.

In conclusion, Meta's capital return strategy in Q3 2025 reflects a mature technology company that is capable of rewarding its shareholders while also investing aggressively for the long term. While the significant increase in spending on AI infrastructure introduces new risks, the company's robust cash flow generation currently allows it to pursue this dual mandate without compromising its financial stability. The ultimate impact on shareholder value will be determined by the success of its ambitious AI-driven growth initiatives.